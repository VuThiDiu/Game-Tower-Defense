package TowerDefense.UI;

public interface  ClickListener {
    public void onClick();
}
