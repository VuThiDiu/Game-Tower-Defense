package TowerDefense.Begin;

import static TowerDefense.Begin.Game.heath_player;

public class Launch
{
    public static void main(String[] args) {
        Game game=  new Game("Tower Defense",1280, 1000);
    }
}
